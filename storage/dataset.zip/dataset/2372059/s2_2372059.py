def main():
    #int j
    j = int (input('Jumlah Suku:'))
    #int a
    a = int (input('Awal:'))
    #int i
    i = int (input('Increment:'))
    #str o
    o = str (input('Oprasi(+,-,*)'))
    
    if(o=='+'):
        for tbh in range (0,n):
            
               
    
main()