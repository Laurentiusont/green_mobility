def main():
    n = int(input("N : "))
    
    if (n%n == 0) and (n%1==0) :
        print ("prima")
    else:
        print ("bukan prima")
main()