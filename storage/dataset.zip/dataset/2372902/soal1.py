def main():
    #int bilangan
    n = int(input('n: '))
    
    #operasi bil
    if n % 2 ==0:
        print('genap')
    else:
        print('bukan genap')

main()