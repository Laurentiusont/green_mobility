def main():
    angka = int(input("Masukan Angka : "))
    for x in angka (5):
        if (x % 2):
            print("Bilangan Genap")
        else : 
            print("Bukan Genap")
    
    main()