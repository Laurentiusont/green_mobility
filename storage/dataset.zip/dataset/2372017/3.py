def main():
    #int angka
    angka = int(input(""))
    jumlah = 0
    
    for i in range (1,angka+1,1):
        if (angka % 1 ,  angka % angka ==0):
            jumlah = jumlah + 1
        if (jumlah == 2 ):
            print ("prima")
        else :
            print ("bukan prima")
main()