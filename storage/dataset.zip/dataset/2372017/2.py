def main():
suku = int(input("Jumlah Suku : "))
awal = int(input("Awak"))
inc = int(input("Increament"))
op = input("Operasi : ")
    
if(op == +):
    for i in range (suku,awal,inc):
    print(i)
    elif (op == *):
    for i in range (suku,awal,inc):
    print(i)
    elif (op == -):
    for i in range (suku,awal,inc):
    print(i)
main()