def main ():
    
    n = int(input("Masukan N : "))
    
    if (n % 2 == 0 ):
        if (n / n == 1):
            print ("Bilangan prima ")

    elif (n / 3 == 0 and n == 1):
        print ("Bukan bilangan prima")
    
    else:
        print ("Bukan bilanga prima")
     
        
main ()