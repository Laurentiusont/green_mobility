 # File : T04B_2372069.py
 # Penulis : Allegra Rochintaniawan Al-Nazhari
 # Tujuan Program : Program menghitung jumlah deret 
 
def main ():
    n = int(input("Jumlah Suku :"))
    awal = int(input("Awal :"))
    i = int(input("Increment:"))
    o = int(input("Operasi :(+,-,:,*)"))
    
    
    
    

    
    
main ()