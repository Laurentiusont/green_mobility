 # File : T04C_2372069.py
 # Penulis : Allegra Rochintaniawan Al-Nazhari
 # Tujuan Program : Menentukan bilangan prima atau bukan 
def main():
   

main()