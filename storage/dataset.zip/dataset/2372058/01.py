def main ():
    n = int(input('N : '))
    while (n != 9999):
        if (n % 2 == 0):
            print ('genap')
        else :
            print ('ganjil')
        n = int(input('N : '))
main ()